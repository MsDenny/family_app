import 'dart:convert';

import 'package:agora_rtc_engine/agora_rtc_engine.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:http/http.dart' as http;
import 'package:permission_handler/permission_handler.dart';

class AgoraCallService {
  static const _appId = String.fromEnvironment('AGORA_APP_ID');
  static const _tokenEndpoint = String.fromEnvironment('AGORA_TOKEN_ENDPOINT');

  RtcEngine? _engine;
  String? _channel;
  int? remoteUid;

  RtcEngine? get engine => _engine;
  String? get channel => _channel;

  Future<void> join({
    required String channel,
    required void Function(int? uid) onRemoteUserChanged,
  }) async {
    if (_appId.isEmpty || _tokenEndpoint.isEmpty) {
      throw StateError(
        'Agora is not configured yet. Set AGORA_APP_ID and a secure '
        'AGORA_TOKEN_ENDPOINT when running the app.',
      );
    }
    if (channel.trim().isEmpty) {
      throw StateError('A family call room has not been configured.');
    }

    final user = FirebaseAuth.instance.currentUser;
    if (user == null) {
      throw StateError('Sign in again before starting a family call.');
    }

    final camera = await Permission.camera.request();
    final microphone = await Permission.microphone.request();
    if (!camera.isGranted || !microphone.isGranted) {
      throw StateError(
        'Camera and microphone access are needed for a video call. '
        'You can change this in Android app settings.',
      );
    }

    final token = await _requestToken(user, channel);
    final engine = createAgoraRtcEngine();
    _engine = engine;
    _channel = channel;

    try {
      await engine.initialize(RtcEngineContext(appId: _appId));
      await engine.setChannelProfile(
        ChannelProfileType.channelProfileCommunication,
      );
      await engine.enableVideo();
      await engine.startPreview();
      engine.registerEventHandler(
        RtcEngineEventHandler(
          onUserJoined: (connection, uid, elapsed) {
            remoteUid = uid;
            onRemoteUserChanged(uid);
          },
          onUserOffline: (connection, uid, reason) {
            if (remoteUid == uid) {
              remoteUid = null;
              onRemoteUserChanged(null);
            }
          },
          onLeaveChannel: (connection, stats) {
            remoteUid = null;
            onRemoteUserChanged(null);
          },
        ),
      );
      await engine.joinChannel(
        token: token,
        channelId: channel,
        uid: 0,
        options: const ChannelMediaOptions(),
      );
    } catch (_) {
      try {
        await engine.release();
      } catch (_) {
        // Preserve the original join error if cleanup also fails.
      }
      _engine = null;
      _channel = null;
      rethrow;
    }
  }

  Future<String> _requestToken(User user, String channel) async {
    final baseUri = Uri.tryParse(_tokenEndpoint);
    if (baseUri == null ||
        baseUri.scheme != 'https' ||
        !baseUri.hasAuthority) {
      throw StateError('AGORA_TOKEN_ENDPOINT must be a full HTTPS URL.');
    }

    final uri = baseUri.replace(
      queryParameters: {
        ...baseUri.queryParameters,
        'channel': channel,
      },
    );
    final idToken = await user.getIdToken();
    final response = await http
        .get(
          uri,
          headers: {'Authorization': 'Bearer $idToken'},
        )
        .timeout(
          const Duration(seconds: 15),
          onTimeout: () => throw StateError('The Agora token service timed out.'),
        );
    if (response.statusCode != 200) {
      throw StateError(
        'The secure Agora token service could not authorize this call '
        '(HTTP ${response.statusCode}).',
      );
    }

    final payload = jsonDecode(response.body);
    if (payload is! Map<String, dynamic> ||
        payload['token'] is! String ||
        (payload['token'] as String).isEmpty) {
      throw StateError('The Agora token service returned an invalid response.');
    }
    return payload['token'] as String;
  }

  Future<void> leave() async {
    final engine = _engine;
    _engine = null;
    _channel = null;
    remoteUid = null;
    if (engine == null) return;

    try {
      await engine.leaveChannel();
    } catch (_) {
      // Always release the local engine, even if Agora cannot leave cleanly.
    } finally {
      try {
        await engine.release();
      } catch (_) {
        // The engine is already detached from the screen; nothing else to do.
      }
    }
  }
}