import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../models/consent_preferences.dart';

class ConsentStore {
  static const _keyPrefix = 'family_circle.consent.v1.';

  Future<ConsentPreferences?> read(String userId) async {
    final preferences = await SharedPreferences.getInstance();
    final saved = preferences.getString('$_keyPrefix$userId');
    if (saved == null) return null;

    final decoded = jsonDecode(saved);
    if (decoded is! Map<String, dynamic>) {
      throw const FormatException('Consent data could not be read.');
    }
    return ConsentPreferences.fromJson(decoded);
  }

  Future<void> save(String userId, ConsentPreferences consent) async {
    final preferences = await SharedPreferences.getInstance();
    final saved = await preferences.setString(
      '$_keyPrefix$userId',
      jsonEncode(consent.toJson()),
    );
    if (!saved) {
      throw StateError('Your consent choices could not be saved on this device.');
    }
  }
}