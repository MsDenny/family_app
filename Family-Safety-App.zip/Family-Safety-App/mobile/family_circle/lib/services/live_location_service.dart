import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:geolocator/geolocator.dart';

class LiveLocationService {
  Timer? _heartbeat;

  Future<StreamSubscription<Position>> start({
    required String userId,
    required String familyId,
    required void Function(Object error) onError,
  }) async {
    if (familyId.trim().isEmpty) {
      throw StateError(
        'Family location sharing is not configured. Set FAMILY_ID before running the app.',
      );
    }

    final serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      throw StateError('Turn on Android location services to share your location.');
    }

    var permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }
    if (permission == LocationPermission.denied) {
      throw StateError('Location permission was not granted.');
    }
    if (permission == LocationPermission.deniedForever) {
      throw StateError(
        'Location access is blocked. Allow it in Android app settings to continue.',
      );
    }

    final locationDocument = _locationDocument(familyId, userId);
    final firstPosition = await Geolocator.getCurrentPosition(
      locationSettings: const LocationSettings(
        accuracy: LocationAccuracy.high,
        timeLimit: Duration(seconds: 20),
      ),
    );
    await _writePosition(locationDocument, userId, firstPosition);

    var latestPosition = firstPosition;
    _heartbeat?.cancel();
    _heartbeat = Timer.periodic(const Duration(seconds: 30), (_) {
      unawaited(
        _writePosition(locationDocument, userId, latestPosition).catchError(
          (Object error) => onError(error),
        ),
      );
    });

    return Geolocator.getPositionStream(
      locationSettings: const LocationSettings(
        accuracy: LocationAccuracy.high,
        distanceFilter: 0,
      ),
    ).listen(
      (position) {
        latestPosition = position;
        unawaited(
          _writePosition(locationDocument, userId, position).catchError(
            (Object error) => onError(error),
          ),
        );
      },
      onError: (Object error) => onError(error),
    );
  }

  Future<void> stop({
    required String userId,
    required String familyId,
  }) async {
    _heartbeat?.cancel();
    _heartbeat = null;
    if (familyId.trim().isEmpty) return;
    await _locationDocument(familyId, userId).delete();
  }

  DocumentReference<Map<String, dynamic>> _locationDocument(
    String familyId,
    String userId,
  ) {
    return FirebaseFirestore.instance
        .collection('families')
        .doc(familyId)
        .collection('liveLocations')
        .doc(userId);
  }

  Future<void> _writePosition(
    DocumentReference<Map<String, dynamic>> document,
    String userId,
    Position position,
  ) {
    return document.set(
      {
        'uid': userId,
        'latitude': position.latitude,
        'longitude': position.longitude,
        'accuracyMeters': position.accuracy,
        'isSharing': true,
        'updatedAt': FieldValue.serverTimestamp(),
        'expiresAt': Timestamp.fromDate(
          DateTime.now().toUtc().add(const Duration(seconds: 75)),
        ),
      },
      SetOptions(merge: true),
    );
  }
}