import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import 'models/consent_preferences.dart';
import 'screens/consent_screen.dart';
import 'screens/home_screen.dart';
import 'screens/login_screen.dart';
import 'services/consent_store.dart';

const Color forest = Color(0xFF1E5B4B);
const Color forestDark = Color(0xFF143F35);
const Color mint = Color(0xFFE5F2EB);
const Color paper = Color(0xFFF7F8F4);
const Color ink = Color(0xFF1D2824);
const Color mutedInk = Color(0xFF68756F);
const Color coral = Color(0xFFEE795D);

class FamilyCircleApp extends StatelessWidget {
  const FamilyCircleApp({required this.firebaseError, super.key});

  final String? firebaseError;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Family Circle',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: paper,
        colorScheme: ColorScheme.fromSeed(
          seedColor: forest,
          primary: forest,
          secondary: coral,
          surface: Colors.white,
        ),
        fontFamily: 'Roboto',
        textTheme: const TextTheme(
          headlineMedium: TextStyle(
            color: ink,
            fontSize: 30,
            height: 1.12,
            fontWeight: FontWeight.w800,
            letterSpacing: -0.8,
          ),
          titleLarge: TextStyle(
            color: ink,
            fontSize: 20,
          fontWeight: FontWeight.w700,
            letterSpacing: -0.3,
          ),
          bodyLarge: TextStyle(color: ink, fontSize: 16, height: 1.45),
          bodyMedium: TextStyle(color: mutedInk, fontSize: 14, height: 1.45),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white,
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 16, vertical: 17),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: const BorderSide(color: Color(0xFFDCE5DE)),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: const BorderSide(color: Color(0xFFDCE5DE)),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: const BorderSide(color: forest, width: 1.6),
          ),
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: forest,
            foregroundColor: Colors.white,
            minimumSize: const Size.fromHeight(56),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(17),
            ),
            textStyle: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w700,
            ),
          ),
        ),
      ),
      home: firebaseError == null
          ? const _AuthenticationGate()
          : LoginScreen(firebaseError: firebaseError),
    );
  }
}

class _AuthenticationGate extends StatelessWidget {
  const _AuthenticationGate();

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return LoginScreen(
            firebaseError:
                'Could not check your family account. Please try again.',
          );
        }
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const _LoadingScreen();
        }
        final user = snapshot.data;
        return user == null ? const LoginScreen() : _ConsentGate(user: user);
      },
    );
  }
}

class _ConsentGate extends StatefulWidget {
  const _ConsentGate({required this.user});

  final User user;

  @override
  State<_ConsentGate> createState() => _ConsentGateState();
}

class _ConsentGateState extends State<_ConsentGate> {
  final ConsentStore _store = ConsentStore();
  late Future<ConsentPreferences?> _loadConsent;
  ConsentPreferences? _consent;

  @override
  void initState() {
    super.initState();
    _loadConsent = _store.read(widget.user.uid);
  }

  Future<void> _saveConsent(ConsentPreferences preferences) async {
    await _store.save(widget.user.uid, preferences);
    if (!mounted) return;
    setState(() {
      _consent = preferences;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_consent != null) {
      return HomeScreen(
        user: widget.user,
        consent: _consent!,
        onSaveConsent: _saveConsent,
      );
    }

    return FutureBuilder<ConsentPreferences?>(
      future: _loadConsent,
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return _ConsentLoadError(
            onRetry: () => setState(
              () => _loadConsent = _store.read(widget.user.uid),
            ),
          );
        }
        if (snapshot.connectionState != ConnectionState.done) {
          return const _LoadingScreen();
        }

        final existing = snapshot.data;
        if (existing != null) {
          WidgetsBinding.instance.addPostFrameCallback((_) {
            if (mounted && _consent == null) {
              setState(() => _consent = existing);
            }
          });
          return const _LoadingScreen();
        }

        return ConsentScreen(
          onSave: _saveConsent,
          onCancel: () {},
        );
      },
    );
  }
}

class _LoadingScreen extends StatelessWidget {
  const _LoadingScreen();

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Center(
        child: CircularProgressIndicator(color: forest),
      ),
    );
  }
}

class _ConsentLoadError extends StatelessWidget {
  const _ConsentLoadError({required this.onRetry});

  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.lock_clock_rounded, size: 42, color: forest),
              const SizedBox(height: 14),
              Text(
                'Your consent choices could not be loaded.',
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.titleLarge,
              ),
              const SizedBox(height: 18),
              OutlinedButton(onPressed: onRetry, child: const Text('Try again')),
            ],
          ),
        ),
      ),
    );
  }
}