class ConsentPreferences {
  const ConsentPreferences({
    required this.location,
    required this.camera,
    required this.microphone,
  });

  static const empty = ConsentPreferences(
    location: false,
    camera: false,
    microphone: false,
  );

  final bool location;
  final bool camera;
  final bool microphone;

  bool get canVideoCall => camera && microphone;

  Map<String, Object> toJson() => {
        'version': 1,
        'location': location,
        'camera': camera,
        'microphone': microphone,
      };

  factory ConsentPreferences.fromJson(Map<String, dynamic> json) {
    if (json['version'] != 1 ||
        json['location'] is! bool ||
        json['camera'] is! bool ||
        json['microphone'] is! bool) {
      throw const FormatException('Consent data is invalid or out of date.');
    }

    return ConsentPreferences(
      location: json['location'] as bool,
      camera: json['camera'] as bool,
      microphone: json['microphone'] as bool,
    );
  }
}