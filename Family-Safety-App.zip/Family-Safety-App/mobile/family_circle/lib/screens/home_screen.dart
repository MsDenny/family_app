import 'dart:async';

import 'package:agora_rtc_engine/agora_rtc_engine.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';

import '../app.dart';
import '../models/consent_preferences.dart';
import '../services/agora_call_service.dart';
import '../services/live_location_service.dart';
import 'consent_screen.dart';

const _familyId = String.fromEnvironment('FAMILY_ID');

class HomeScreen extends StatefulWidget {
  const HomeScreen({
    required this.user,
    required this.consent,
    required this.onSaveConsent,
    super.key,
  });

  final User user;
  final ConsentPreferences consent;
  final Future<void> Function(ConsentPreferences) onSaveConsent;

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _locationService = LiveLocationService();
  final _callService = AgoraCallService();

  StreamSubscription<Position>? _locationSubscription;
  bool _sharingLocation = false;
  bool _startingLocation = false;
  bool _startingCall = false;
  bool _inCall = false;
  int? _remoteUid;

  String get _displayName {
    final name = widget.user.displayName?.trim();
    if (name != null && name.isNotEmpty) return name.split(' ').first;
    final email = widget.user.email;
    if (email != null && email.contains('@')) return email.split('@').first;
    return 'there';
  }

  void _showMessage(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(message)));
  }

  Future<void> _toggleLocation() async {
    if (_startingLocation) return;
    if (_sharingLocation) {
      setState(() => _startingLocation = true);
      await _locationSubscription?.cancel();
      _locationSubscription = null;
      try {
        await _locationService.stop(
          userId: widget.user.uid,
          familyId: _familyId,
        );
        _showMessage('Live location sharing has stopped.');
      } catch (_) {
        _showMessage('Sharing stopped on this device, but the last location '
            'could not be removed from Firebase.');
      } finally {
        if (mounted) {
          setState(() {
            _sharingLocation = false;
            _startingLocation = false;
          });
        }
      }
      return;
    }

    if (!widget.consent.location) {
      _showMessage('Turn on Live location consent before sharing.');
      return;
    }

    setState(() => _startingLocation = true);
    try {
      _locationSubscription = await _locationService.start(
        userId: widget.user.uid,
        familyId: _familyId,
        onError: (error) {
          unawaited(_handleLocationStreamError(error));
        },
      );
      if (mounted) {
        setState(() {
          _sharingLocation = true;
          _startingLocation = false;
        });
        _showMessage('Your family can now see your live location.');
      }
    } catch (error) {
      if (mounted) {
        setState(() => _startingLocation = false);
        _showMessage(error.toString().replaceFirst('Bad state: ', ''));
      }
    }
  }

  Future<void> _handleLocationStreamError(Object error) async {
    await _locationSubscription?.cancel();
    _locationSubscription = null;
    try {
      await _locationService.stop(
        userId: widget.user.uid,
        familyId: _familyId,
      );
    } catch (_) {
      // The stream is stopped even when Firebase cannot remove its last point.
    }
    if (!mounted) return;
    setState(() => _sharingLocation = false);
    _showMessage('Live location sharing stopped because an update failed.');
  }

  Future<void> _toggleCall() async {
    if (_startingCall) return;
    if (_inCall) {
      setState(() {
        _startingCall = true;
        _inCall = false;
        _remoteUid = null;
      });
      await _callService.leave();
      if (!mounted) return;
      setState(() {
        _startingCall = false;
      });
      return;
    }

    if (!widget.consent.camera || !widget.consent.microphone) {
      _showMessage('Turn on Camera and Microphone consent before calling.');
      return;
    }
    if (_familyId.isEmpty) {
      _showMessage('Set FAMILY_ID to connect your family call room.');
      return;
    }

    setState(() => _startingCall = true);
    try {
      await _callService.join(
        channel: _familyId,
        onRemoteUserChanged: (uid) {
          if (mounted) setState(() => _remoteUid = uid);
        },
      );
      if (mounted) {
        setState(() {
          _inCall = true;
          _startingCall = false;
        });
      }
    } catch (error) {
      if (mounted) {
        setState(() => _startingCall = false);
        _showMessage(error.toString().replaceFirst('Bad state: ', ''));
      }
    }
  }

  Future<void> _signOut() async {
    await _stopLocationSilently();
    await _callService.leave();
    await FirebaseAuth.instance.signOut();
  }

  Future<void> _openConsentSettings() async {
    final updatedConsent = await Navigator.of(context).push<ConsentPreferences>(
      MaterialPageRoute(
        builder: (_) => ConsentScreen(
          initialPreferences: widget.consent,
          isEditing: true,
          onCancel: () => Navigator.of(context).pop(),
          onSave: (preferences) async =>
              Navigator.of(context).pop(preferences),
        ),
      ),
    );
    if (updatedConsent == null || !mounted) return;

    final previousConsent = widget.consent;
    await widget.onSaveConsent(updatedConsent);
    if (previousConsent.location && !updatedConsent.location) {
      await _stopLocationSilently();
      if (mounted) {
        setState(() => _sharingLocation = false);
      }
    }
    if (_inCall && previousConsent.canVideoCall && !updatedConsent.canVideoCall) {
      setState(() {
        _inCall = false;
        _remoteUid = null;
      });
      await _callService.leave();
    }
  }

  Future<void> _stopLocationSilently() async {
    await _locationSubscription?.cancel();
    _locationSubscription = null;
    try {
      await _locationService.stop(
        userId: widget.user.uid,
        familyId: _familyId,
      );
    } catch (_) {
      // Signing out must not be blocked by a temporary network failure.
    }
  }

  @override
  void dispose() {
    unawaited(_stopLocationSilently());
    unawaited(_callService.leave());
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: paper,
        titleSpacing: 20,
        title: const Row(
          children: [
            Icon(Icons.diversity_1_rounded, color: forest, size: 27),
            SizedBox(width: 9),
            Text(
              'family circle',
              style: TextStyle(
                color: forestDark,
                fontSize: 18,
                fontWeight: FontWeight.w800,
              ),
            ),
          ],
        ),
        actions: [
          PopupMenuButton<String>(
            tooltip: 'Account and privacy',
            icon: const Icon(Icons.more_horiz_rounded),
            onSelected: (value) {
              if (value == 'consent') unawaited(_openConsentSettings());
              if (value == 'signout') unawaited(_signOut());
            },
            itemBuilder: (context) => const [
              PopupMenuItem(
                value: 'consent',
                child: ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: Icon(Icons.tune_rounded),
                  title: Text('Privacy choices'),
                ),
              ),
              PopupMenuItem(
                value: 'signout',
                child: ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: Icon(Icons.logout_rounded),
                  title: Text('Sign out'),
                ),
              ),
            ],
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: SafeArea(
        top: false,
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 600),
            child: ListView(
              padding: const EdgeInsets.fromLTRB(22, 13, 22, 30),
              children: [
                Text(
                  'Good to see you,\n$_displayName.',
                  style: Theme.of(context).textTheme.headlineMedium,
                ),
                const SizedBox(height: 8),
                Text(
                  'A little closer, whenever you need.',
                  style: Theme.of(context)
                      .textTheme
                      .bodyLarge
                      ?.copyWith(color: mutedInk),
                ),
                const SizedBox(height: 22),
                _FamilyStatusCard(
                  location: _sharingLocation,
                  video: _inCall,
                ),
                const SizedBox(height: 20),
                Text(
                  'Stay connected',
                  style: Theme.of(context).textTheme.titleLarge,
                ),
                const SizedBox(height: 12),
                _FeatureCard(
                  icon: Icons.video_call_rounded,
                  iconColor: const Color(0xFFB45C43),
                  iconBackground: const Color(0xFFFFE9E1),
                  title: _inCall ? 'Video call is live' : 'Video calling',
                  subtitle: _inCall
                      ? _remoteUid == null
                          ? 'Waiting for a family member to join…'
                          : 'You are connected with your family.'
                      : 'See and hear your family with Agora.',
                  child: _inCall
                      ? _CallPreview(
                          engine: _callService.engine!,
                          channel: _callService.channel!,
                          remoteUid: _remoteUid,
                        )
                      : null,
                  buttonLabel: _inCall ? 'End call' : 'Start a video call',
                  buttonIcon:
                      _inCall ? Icons.call_end_rounded : Icons.videocam_rounded,
                  buttonColor: _inCall ? const Color(0xFFB5463C) : forest,
                  busy: _startingCall,
                  onPressed: _toggleCall,
                ),
                const SizedBox(height: 13),
                _FeatureCard(
                  icon: Icons.near_me_rounded,
                  iconColor: const Color(0xFF3F6D8B),
                  iconBackground: const Color(0xFFE6F1F8),
                  title: _sharingLocation
                      ? 'Location is sharing'
                      : 'Share live location',
                  subtitle: _sharingLocation
                      ? 'Your family can see your latest location. Stop any time.'
                      : 'Share your live location with family, only while you choose.',
                  buttonLabel:
                      _sharingLocation ? 'Stop sharing' : 'Share my location',
                  buttonIcon: _sharingLocation
                      ? Icons.location_off_rounded
                      : Icons.my_location_rounded,
                  buttonColor: _sharingLocation
                      ? const Color(0xFFB5463C)
                      : const Color(0xFF356A87),
                  busy: _startingLocation,
                  onPressed: _toggleLocation,
                ),
                const SizedBox(height: 16),
                Container(
                  padding: const EdgeInsets.all(15),
                  decoration: BoxDecoration(
                    color: const Color(0xFFF0F2EB),
                    borderRadius: BorderRadius.circular(17),
                  ),
                  child: const Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Icon(Icons.info_outline_rounded, color: forest, size: 20),
                      SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          'Location sharing runs while this app is open. You can stop it here or turn off consent in Privacy choices.',
                          style: TextStyle(
                            color: Color(0xFF52645B),
                            fontSize: 13,
                            height: 1.4,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 11),
                TextButton.icon(
                  onPressed: () => unawaited(_openConsentSettings()),
                  icon: const Icon(Icons.tune_rounded, size: 18),
                  label: const Text('Review my privacy choices'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _FamilyStatusCard extends StatelessWidget {
  const _FamilyStatusCard({required this.location, required this.video});

  final bool location;
  final bool video;

  @override
  Widget build(BuildContext context) {
    final status = video
        ? 'On a family call'
        : location
            ? 'Sharing location'
            : 'Your circle is ready';
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [forest, Color(0xFF2B7560)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(22),
      ),
      child: Row(
        children: [
          Container(
            height: 50,
            width: 50,
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.15),
              borderRadius: BorderRadius.circular(17),
            ),
            child: const Icon(
              Icons.favorite_rounded,
              color: Color(0xFFFFD2BC),
              size: 27,
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Your family circle',
                  style: TextStyle(
                    color: Colors.white70,
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  status,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _FeatureCard extends StatelessWidget {
  const _FeatureCard({
    required this.icon,
    required this.iconColor,
    required this.iconBackground,
    required this.title,
    required this.subtitle,
    required this.buttonLabel,
    required this.buttonIcon,
    required this.buttonColor,
    required this.busy,
    required this.onPressed,
    this.child,
  });

  final IconData icon;
  final Color iconColor;
  final Color iconBackground;
  final String title;
  final String subtitle;
  final String buttonLabel;
  final IconData buttonIcon;
  final Color buttonColor;
  final bool busy;
  final VoidCallback onPressed;
  final Widget? child;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(17),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(21),
        border: Border.all(color: const Color(0xFFE5EAE5)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                height: 44,
                width: 44,
                decoration: BoxDecoration(
                  color: iconBackground,
                  borderRadius: BorderRadius.circular(15),
                ),
                child: Icon(icon, color: iconColor, size: 24),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.only(top: 2),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        style: const TextStyle(
                          color: ink,
                          fontSize: 16,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        subtitle,
                        style: const TextStyle(
                          color: mutedInk,
                          fontSize: 13,
                          height: 1.35,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
          if (child != null) ...[
            const SizedBox(height: 14),
            child!,
          ],
          const SizedBox(height: 15),
          SizedBox(
            height: 48,
            child: FilledButton.icon(
              style: FilledButton.styleFrom(
                backgroundColor: buttonColor,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14),
                ),
                textStyle: const TextStyle(fontWeight: FontWeight.w700),
              ),
              onPressed: busy ? null : onPressed,
              icon: busy
                  ? const SizedBox(
                      height: 18,
                      width: 18,
                      child: CircularProgressIndicator(
                        color: Colors.white,
                        strokeWidth: 2,
                      ),
                    )
                  : Icon(buttonIcon, size: 19),
              label: Text(busy ? 'Please wait…' : buttonLabel),
            ),
          ),
        ],
      ),
    );
  }
}

class _CallPreview extends StatelessWidget {
  const _CallPreview({
    required this.engine,
    required this.channel,
    required this.remoteUid,
  });

  final RtcEngine engine;
  final String channel;
  final int? remoteUid;

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(16),
      child: SizedBox(
        height: 214,
        child: remoteUid == null
            ? Stack(
                fit: StackFit.expand,
                children: [
                  AgoraVideoView(
                    controller: VideoViewController(
                      rtcEngine: engine,
                      canvas: const VideoCanvas(uid: 0),
                    ),
                  ),
                  Positioned(
                    left: 10,
                    bottom: 10,
                    child: DecoratedBox(
                      decoration: BoxDecoration(
                        color: Colors.black.withValues(alpha: 0.55),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: const Padding(
                        padding:
                            EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                        child: Text(
                          'Waiting for family',
                          style: TextStyle(color: Colors.white, fontSize: 12),
                        ),
                      ),
                    ),
                  ),
                ],
              )
            : AgoraVideoView(
                controller: VideoViewController.remote(
                  rtcEngine: engine,
                  canvas: VideoCanvas(uid: remoteUid),
                  connection: RtcConnection(channelId: channel),
                ),
              ),
      ),
    );
  }
}