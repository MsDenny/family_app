import 'package:flutter/material.dart';

import '../app.dart';
import '../models/consent_preferences.dart';

class ConsentScreen extends StatefulWidget {
  const ConsentScreen({
    required this.onSave,
    required this.onCancel,
    this.initialPreferences = ConsentPreferences.empty,
    this.isEditing = false,
    super.key,
  });

  final ConsentPreferences initialPreferences;
  final bool isEditing;
  final Future<void> Function(ConsentPreferences) onSave;
  final VoidCallback onCancel;

  @override
  State<ConsentScreen> createState() => _ConsentScreenState();
}

class _ConsentScreenState extends State<ConsentScreen> {
  late bool _location = widget.initialPreferences.location;
  late bool _camera = widget.initialPreferences.camera;
  late bool _microphone = widget.initialPreferences.microphone;
  bool _saving = false;
  String? _error;

  Future<void> _save() async {
    setState(() {
      _saving = true;
      _error = null;
    });
    try {
      await widget.onSave(
        ConsentPreferences(
          location: _location,
          camera: _camera,
          microphone: _microphone,
        ),
      );
    } catch (_) {
      if (mounted) {
        setState(
          () => _error = 'Your choices could not be saved. Please try again.',
        );
      }
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: widget.isEditing
          ? AppBar(
              backgroundColor: paper,
              leading: IconButton(
                tooltip: 'Back without saving',
                onPressed: widget.onCancel,
                icon: const Icon(Icons.arrow_back_rounded),
              ),
              title: const Text('Privacy choices'),
            )
          : null,
      body: SafeArea(
        top: !widget.isEditing,
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 560),
            child: Column(
              children: [
                Expanded(
                  child: ListView(
                    padding: const EdgeInsets.fromLTRB(24, 18, 24, 18),
                    children: [
                      if (!widget.isEditing) ...[
                        _ConsentBrand(),
                        const SizedBox(height: 26),
                      ],
                      Text(
                        widget.isEditing
                            ? 'Your choices, your call.'
                            : 'Before you connect',
                        style: Theme.of(context).textTheme.headlineMedium,
                      ),
                      const SizedBox(height: 9),
                      Text(
                        'Choose what you are comfortable sharing. You can leave any option off and change it later.',
                        style: Theme.of(context)
                            .textTheme
                            .bodyLarge
                            ?.copyWith(color: mutedInk),
                      ),
                      const SizedBox(height: 18),
                      _ConsentTile(
                        icon: Icons.location_on_rounded,
                        title: 'Live location',
                        subtitle:
                            'Share your location with your family while live sharing is on.',
                        value: _location,
                        onChanged: (value) => setState(() => _location = value),
                      ),
                      const SizedBox(height: 11),
                      _ConsentTile(
                        icon: Icons.videocam_rounded,
                        title: 'Camera',
                        subtitle:
                            'Let Family Circle use your camera during an Agora video call.',
                        value: _camera,
                        onChanged: (value) => setState(() => _camera = value),
                      ),
                      const SizedBox(height: 11),
                      _ConsentTile(
                        icon: Icons.mic_rounded,
                        title: 'Microphone',
                        subtitle:
                            'Let Family Circle use your microphone during a video call.',
                        value: _microphone,
                        onChanged: (value) =>
                            setState(() => _microphone = value),
                      ),
                      const SizedBox(height: 18),
                      Container(
                        padding: const EdgeInsets.all(15),
                        decoration: BoxDecoration(
                          color: const Color(0xFFFFF3E9),
                          borderRadius: BorderRadius.circular(17),
                        ),
                        child: const Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Icon(
                              Icons.shield_outlined,
                              size: 21,
                              color: Color(0xFF9A5A30),
                            ),
                            SizedBox(width: 11),
                            Expanded(
                              child: Text(
                                'These switches record your choice on this device. Android will also ask for access the first time you use each feature.',
                                style: TextStyle(
                                  color: Color(0xFF704A34),
                                  height: 1.4,
                                  fontSize: 13,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      if (_error != null) ...[
                        const SizedBox(height: 12),
                        Text(
                          _error!,
                          style: const TextStyle(color: Colors.red),
                        ),
                      ],
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(24, 8, 24, 20),
                  child: ElevatedButton(
                    onPressed: _saving ? null : _save,
                    child: _saving
                        ? const SizedBox(
                            height: 22,
                            width: 22,
                            child: CircularProgressIndicator(
                              color: Colors.white,
                              strokeWidth: 2,
                            ),
                          )
                        : Text(
                            widget.isEditing ? 'Save choices' : 'Continue',
                          ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _ConsentBrand extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          height: 44,
          width: 44,
          decoration: BoxDecoration(
            color: mint,
            borderRadius: BorderRadius.circular(15),
          ),
          child: const Icon(Icons.diversity_1_rounded, color: forest, size: 25),
        ),
        const SizedBox(width: 11),
        const Text(
          'family circle',
          style: TextStyle(
            color: forestDark,
            fontSize: 17,
            fontWeight: FontWeight.w800,
          ),
        ),
      ],
    );
  }
}

class _ConsentTile extends StatelessWidget {
  const _ConsentTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.value,
    required this.onChanged,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final bool value;
  final ValueChanged<bool> onChanged;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(15, 14, 9, 14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(19),
        border: Border.all(color: const Color(0xFFE3E9E3)),
      ),
      child: Row(
        children: [
          Container(
            height: 42,
            width: 42,
            decoration: BoxDecoration(
              color: value ? mint : const Color(0xFFF0F2EE),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Icon(icon, color: value ? forest : mutedInk, size: 22),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    color: ink,
                    fontWeight: FontWeight.w700,
                    fontSize: 15,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  subtitle,
                  style: const TextStyle(
                    color: mutedInk,
                    fontSize: 12.5,
                    height: 1.35,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          Switch.adaptive(
            value: value,
            onChanged: onChanged,
            activeTrackColor: forest,
          ),
        ],
      ),
    );
  }
}