# Family Circle (Flutter / Android)

A three-screen family app: Firebase email/password login, a consent screen with
separate location/camera/microphone switches, and a home screen for Agora video
calls and Firebase live-location sharing.

This workspace does not have Flutter, Dart, or the Android build tools installed,
so the source has not been compiled or previewed here.

## What works in the app

- Email/password sign-in and account creation through Firebase Authentication.
- Consent choices are separate from Android's runtime permission prompts. Android
  requests camera/microphone access only when a consented video call is started,
  and location access only when consented live sharing is started.
- Each signed-in account's consent choices are saved on that device.
- Live location writes the signed-in member's latest position to Firestore and
  removes that location document when sharing stops.
- Agora calls use a secure token endpoint; the app never embeds an Agora
  certificate or accepts an insecure client-generated token.

## Setup

1. Install Flutter 3.29 or later and Android Studio on a development computer,
   then run `flutter create . --platforms=android` from this directory to
   generate the standard Android wrapper files if they are not present. Keep the
   permissions declared in `android/app/src/main/AndroidManifest.xml`.
2. Create a Firebase project and register its Android app using package name
   `com.example.family_circle`. Copy the app's **API key**, **App ID**,
   **Messaging sender ID**, and the Firebase **Project ID** from Project
   settings. These are Firebase client configuration values, not server
   credentials.
3. In Firebase Authentication, enable **Email/Password**. Create a Cloud
   Firestore database and publish `firestore.rules` from this directory.
4. For each family member, create a membership document at
   `families/{FAMILY_ID}/members/{FIREBASE_UID}`. Membership documents should
   only be provisioned by a trusted administrator or backend; the app rules
   intentionally deny clients permission to create them.
5. Configure Agora in its console and provide a secure HTTPS token service. The
   token service must verify the Firebase ID token, confirm the user is a member
   of the requested family, and return JSON in the form `{"token":"..."}` for
   the requested channel. Never put an Agora App Certificate in this app.
6. Install dependencies and run on an Android device:

   ```sh
   flutter pub get
   flutter run \
     --dart-define=FIREBASE_API_KEY=your-firebase-api-key \
     --dart-define=FIREBASE_APP_ID=your-firebase-app-id \
     --dart-define=FIREBASE_MESSAGING_SENDER_ID=your-sender-id \
     --dart-define=FIREBASE_PROJECT_ID=your-project-id \
     --dart-define=FAMILY_ID=your-family-id \
     --dart-define=AGORA_APP_ID=your-agora-app-id \
     --dart-define=AGORA_TOKEN_ENDPOINT=https://your-api.example.com/agora/token
   ```

   `FAMILY_ID` must match the Firestore family document and the family channel
   authorized by the Agora token service.

## Privacy and platform notes

- A consent switch records the person's choice; it does not itself grant Android
  permission. A feature remains unavailable when its corresponding consent is
  off, even if Android permission was granted previously.
- Location sharing is foreground-only in this initial Android implementation:
  it updates while the app is open, and stops when the user taps **Stop sharing**,
  signs out, or revokes location consent. Location documents expire from family
  reads 75 seconds after the last successful update, so force-closing the app
  does not leave a readable stale location. Background sharing needs a
  separately configured Android foreground service and its persistent
  notification.
- Consent choices are stored locally per Firebase user on the current device.
  They are not a legal consent record or a synced family setting.
- Firestore rules restrict reads to family members and writes/deletes to the
  member's own location document. Family membership setup is an administrator
  responsibility.